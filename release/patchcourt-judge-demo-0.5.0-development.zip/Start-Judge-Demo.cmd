@echo off
setlocal
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0launch_demo.py"
    goto :finished
)
where python >nul 2>nul
if not errorlevel 1 (
    python "%~dp0launch_demo.py"
    goto :finished
)
echo Python 3 is required. Install Python, then double-click this file again.
:finished
if errorlevel 1 pause
endlocal
